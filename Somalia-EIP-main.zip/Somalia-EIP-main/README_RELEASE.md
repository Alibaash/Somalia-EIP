# Somalia-Economic-Intelligence-Platform

Somalia Market Intelligence is a real-time economic analytics platform that collects, validates, and visualizes Somalia market data, including exchange rates, fuel prices, commodity trends, and risk indicators. Built with Python, SQLite, and Streamlit for monitoring and decision support.

## Local Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/Alibaash/Somalia-Economic-Intelligence-Platform.git
   cd Somalia-Economic-Intelligence-Platform
   ```
2. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```
3. Install Python dependencies:
   ```bash
   python -m pip install --upgrade pip setuptools
   pip install -r requirements.txt
   ```

## Running the Dashboard

Start the Streamlit dashboard locally:

```bash
streamlit run dashboard/app.py --server.port 8501 --server.address 0.0.0.0
```

Then open `http://localhost:8501` in your browser.

## Running Tests

Run the full test suite with pytest:

```bash
python -m pytest tests/ -q
```

## Deploy to Streamlit Community Cloud

Use these settings when deploying to Streamlit Community Cloud:

- Repository: `Alibaash/Somalia-Economic-Intelligence-Platform`
- Branch: `main`
- Main file path: `dashboard/app.py`
- Optional secret: `SOMALIA_EIP_DB_PATH`
  - Example: `/tmp/somalia_eip.db`

> Streamlit Community Cloud uses ephemeral storage for the app environment. Store your database outside the repository checkout if you need persistence, and use `SOMALIA_EIP_DB_PATH` or an external service for production storage.

For production-grade deployments, consider using an external managed database or object storage backend instead of relying on local SQLite files in the Cloud environment.

## Docker Deployment

Build the container image:

```bash
docker build -t somalia-eip .
```

Run the container:

```bash
docker run --rm -p 8501:8501 \
  -e SOMALIA_EIP_DB_PATH=/tmp/somalia_eip.db \
  somalia-eip
```

## GitHub Actions / CI

A GitHub Actions workflow is configured to:

- install dependencies
- run `python -m pytest tests/ -q`

This workflow runs on pushes and pull requests targeting the `main` branch.

## Environment Variables

- `SOMALIA_EIP_DB_PATH` - path to the SQLite database file used by the application.

## Project Structure

- `dashboard/` - Streamlit dashboard source files
- `requirements.txt` - Python dependency list
- `Dockerfile` - container build instructions
- `tests/` - automated test cases
- `README.md` - project overview and usage instructions
- `.github/workflows/` - CI workflow definitions

## Data Sources

The platform ingests and visualizes data from multiple sources relevant to Somalia's economic environment, including market indicators, fuel price feeds, and commodity trends.

## Known Data Limitations

- World Bank does not currently provide modern Somalia exchange-rate records.
  - Telecom indicators are optional and depend on source availability.
