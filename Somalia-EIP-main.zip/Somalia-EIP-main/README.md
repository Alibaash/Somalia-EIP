# Somalia-EIP

Somalia Economic Intelligence Platform (EIP)

## Features

- Exchange Rate Analytics
- Fuel Price Monitoring
- Economic Risk Dashboard
- Streamlit Web Interface
- SQLite Data Storage
- Automated Data Ingestion
- Historical Regime Separation
- Market Intelligence Reporting

## Stack

- Python
- Streamlit
- SQLite
- Pandas
- Plotly

## Run

```bash
pip install -r requirements.txt
python run_scheduler.py
streamlit run dashboard/app.py
